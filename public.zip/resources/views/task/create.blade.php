<!-- <h1>Hello</h1> -->
@extends('layouts.app')
@section('content')
@if ($message = Session::get('msg'))
<div class="alert alert-success alert-block">
    <button type="button" class="close" data-dismiss="alert">×</button>    
    <strong>{{ $message }}</strong>
</div>
@endif
<div class="container">

<h3>Add Task</h3>
<form class="well form-horizontal" action="{{ url('task/store') }}" method="post">
  @csrf
    <fieldset>
        <legend>Add Task</legend>
        <div class="form-group">
            <label class="col-md-4 control-label">Task-Details</label>
            <div class="col-md-4 ">
                <div class="input-group">
                    <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                    <textarea name="taskdetails" class="form-control" type="text"> 
                  </textarea>
                </div>
            </div>
        </div>
     
        <div class="form-group">
            <label class="col-md-4 control-label">Task-Type</label>
            <div class="col-md-4 ">
                <div class="input-group">
                    <select name="tasktype" class="form-control" id="">
                    <option value="">----Select Type----</option>
                    <option value="A">A</option>
                    <option value="B">B</option>
                    <option value="C">C</option>
                    <option value="D">D</option>

                    </select>
            </div>
        </div>

        <div class="form-group">
            <label class="col-md-4 control-label">Status</label>
            <div class="col-md-4 ">
            <select name="status" class="form-control" id="">
            <option value="">----Select Status----</option>
                        <option value="1">Pending</option>
                        <option value="2">Done</option>
</select>
            </div>
        </div>

        <div class="form-group">
            <label class="col-md-4 control-label">Select User</label>
            <div class="col-md-4 ">
            <select name="user" class="form-control" id="">
            <option value="">----Select User----</option>
                        @foreach($users as $user)
                        
                        

                        <option value="{{$user->id}}">{{$user->name}}</option>


                        @endforeach
            
</select>
            </div>
        </div>  
    

        <div class="form-group">
            <label class="col-md-4 control-label"></label>
            <div class="col-md-4">
                <button type="submit" class="btn btn-primary login-button">Submit</button>
            </div>
        </div>

    </fieldset>
</form>
</div>


<script>  
</script>
@endsection
