<!-- <h1>Hello</h1> -->

<?php $__env->startSection('content'); ?>
<?php if($message = Session::get('msg')): ?>
<div class="alert alert-success alert-block">
    <button type="button" class="close" data-dismiss="alert">×</button>    
    <strong><?php echo e($message); ?></strong>
</div>
<?php endif; ?>

<div class="container">
    
<div class="row d-flex justify-content-center">

   <div class="col-sm-6 m-2 p-3" id="box">
<center><h4>Add User</h4></center>
<form class="well form-horizontal" action="<?php echo e(url('store')); ?>" method="post">
  <?php echo csrf_field(); ?>
    <fieldset>
   
        <div class="form-group">
            <label class="col-md-5 control-label">Name</label>
            <div class="col-md-12 ">
                <div class="input-group">
                    <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                    <input name="name" maxlength="30" placeholder="Name" class="form-control" type="text" onkeypress="return (event.charCode > 64 && event.charCode < 91) || (event.charCode > 96 && event.charCode < 123)" >
                </div>
                <br/>
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
         <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                
            </div>
         
        </div>
     
        <div class="form-group">
            <label class="col-md-5 control-label">E-Mail</label>
            <div class="col-md-12 ">
                <div class="input-group">
                    <span class="input-group-addon"><i class="glyphicon glyphicon-envelope"></i></span>
                    <input name="email" maxlength="30" placeholder="E-Mail" id="email" class="form-control" type="text">
                </div>
                <span class="error text-danger"
                id="invalid_email">
              Email-id is invalid
          </span>
                <br/>
               
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
         <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
           
        </div>

        <div class="form-group">
            <label class="col-md-5 control-label">Mobile</label>
            <div class="col-md-12 ">
                <div class="input-group">
                    <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
                    <input name="mobile" maxlength="12"  placeholder="Enter Mobile Number"class="form-control" type="number">
                </div>
                <br/>
                <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                       <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            
        </div>
        <div class="form-group">
            <label class="col-md-5 control-label"></label>
            <div class="col-md-12">
                <button type="submit" id="submit" class="btn btn-primary login-button">Save</button>
            </div>
        </div>

    </fieldset>
</form>
</div>
</div>

</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\my-Trainee_Task\resources\views/users/create.blade.php ENDPATH**/ ?>