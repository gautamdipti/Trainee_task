
 <!DOCTYPE html>
<html>
<head>
    <title>Email Validation Form</title>
</head>
<body>
    <h2>Email Validation Form</h2>
    <?php if(session('success')): ?>
        <p style="color: green;"><?php echo e(session('success')); ?></p>
    <?php endif; ?>
<form action="<?php echo e(url('store')); ?>" method="POST">
<?php echo csrf_field(); ?>
<label for="email">Email:</label>
 <input type="text" id="email" name="email" required>
  <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p style="color: red;"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <br>
        <input type="submit" value="Submit">
    </form>
    </body>
</html><?php /**PATH E:\xampp\htdocs\my-Trainee_Task\resources\views/validation.blade.php ENDPATH**/ ?>