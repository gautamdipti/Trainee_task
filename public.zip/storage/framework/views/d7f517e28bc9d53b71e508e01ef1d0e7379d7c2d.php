<!-- <h1>Hello</h1> -->

<?php $__env->startSection('content'); ?>
<?php if($message = Session::get('msg')): ?>
<div class="alert alert-success alert-block">
    <button type="button" class="close" data-dismiss="alert">×</button>    
    <strong><?php echo e($message); ?></strong>
</div>
<?php endif; ?>
<div class="container">

<h3>Add Task</h3>
<form class="well form-horizontal" action="<?php echo e(url('task/store')); ?>" method="post">
  <?php echo csrf_field(); ?>
    <fieldset>
        <legend>Add Task</legend>
        <div class="form-group">
            <label class="col-md-4 control-label">Task-Details</label>
            <div class="col-md-4 ">
                <div class="input-group">
                    <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                    <textarea name="taskdetails" class="form-control" type="text"> 
                  </textarea>
                </div>
            </div>
        </div>
     
        <div class="form-group">
            <label class="col-md-4 control-label">Task-Type</label>
            <div class="col-md-4 ">
                <div class="input-group">
                    <select name="tasktype" class="form-control" id="">
                    <option value="">----Select Type----</option>
                    <option value="A">A</option>
                    <option value="B">B</option>
                    <option value="C">C</option>
                    <option value="D">D</option>

                    </select>
            </div>
        </div>

        <div class="form-group">
            <label class="col-md-4 control-label">Status</label>
            <div class="col-md-4 ">
            <select name="status" class="form-control" id="">
            <option value="">----Select Status----</option>
                        <option value="1">Pending</option>
                        <option value="2">Done</option>
</select>
            </div>
        </div>

        <div class="form-group">
            <label class="col-md-4 control-label">Select User</label>
            <div class="col-md-4 ">
            <select name="user" class="form-control" id="">
            <option value="">----Select User----</option>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                        

                        <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>


                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
</select>
            </div>
        </div>  
    

        <div class="form-group">
            <label class="col-md-4 control-label"></label>
            <div class="col-md-4">
                <button type="submit" class="btn btn-primary login-button">Submit</button>
            </div>
        </div>

    </fieldset>
</form>
</div>


<script>  
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\my-Trainee_Task\resources\views/task/create.blade.php ENDPATH**/ ?>