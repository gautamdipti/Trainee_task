

<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
<div class="row">
    <div class="col-12">
      <div class="card">
        <div class="card-header">
          <h3 class="card-title"><strong>Task List</strong></h3>
          <div class="text-right">
          </div>
          
        </div>
        <!-- /.card-header -->
        <div class="card-body table-responsive p-0" style="height: 300px;">
        <?php if($message = Session::get('msg')): ?>
<div class="alert alert-success alert-block">
    <button type="button" class="close" data-dismiss="alert">×</button>    
    <strong><?php echo e($message); ?></strong>
</div>
<?php endif; ?>
          <table class="table table-head-fixed text-nowrap">
            <thead>
              <tr>
                
                <th>Id</th>
                <th>Task Details</th>
                <th>Task Type</th>
                <th>Assigned Users</th>
                <!-- <th>User Email</th> -->
                <th>Status</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              <?php if(isset($tasks)): ?>
                <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($task->id); ?></td>
                <td><?php echo e($task->task_details); ?></td>
                <td><?php echo e($task->task_type); ?></td>
                <td><?php echo e($task->assigned_users); ?></td>
                <?php if($task->status=='1'): ?>
                <td class="text-danger">Pending</td>
                <?php elseif($task->status=='2'): ?>
                <td class="text-success">Done</td>

                <?php endif; ?>
                
                <td>Action</td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>
            </tbody>
          </table>

          <?php echo e($tasks->links()); ?>

        </div>
        <!-- /.card-body -->
      </div>
      <!-- /.card -->
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\my-Trainee_Task\resources\views/task/index.blade.php ENDPATH**/ ?>