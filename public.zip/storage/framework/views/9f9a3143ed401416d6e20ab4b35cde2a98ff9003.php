

<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
<div class="row">
    <div class="col-12">
      <div class="card">
        <div class="card-header">
          <h3 class="card-title"><strong>Users</strong> <a href="<?php echo e(url('add-task')); ?>" class="btn btn-info" style="float:right; font-size:17px;">Add Task</a></h3>
          <div class="text-right">
          </div>
          
        </div>
        <!-- /.card-header -->
        <div class="card-body table-responsive p-0" style="height: 300px;">
        <?php if($message = Session::get('msg')): ?>
<div class="alert alert-success alert-block">
    <button type="button" class="close" data-dismiss="alert">×</button>    
    <strong><?php echo e($message); ?></strong>
</div>
<?php endif; ?>
          <table class="table table-head-fixed text-nowrap">
            <thead>
              <tr>
                
                <th>Id</th>
                <th>Name</th>
                <th>Email</th>
                <th>Mobile</th>
               
              </tr>
            </thead>
            <tbody>
              <?php if(isset($shows)): ?>
                <?php $__currentLoopData = $shows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($value->id); ?></td>
                <td><?php echo e($value->name); ?></td>
                <td><?php echo e($value->email); ?></td>
                <td><?php echo e($value->mobile); ?></td>
               
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>
            </tbody>
          </table>

          <?php echo e($shows->links()); ?>

        </div>
        <!-- /.card-body -->
      </div>
      <!-- /.card -->
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\my-Trainee_Task\resources\views/users/users.blade.php ENDPATH**/ ?>